#ifndef MODULES_DB_H
#define MODULES_DB_H

#include <stdio.h>
#include <stdlib.h>

void menu();
void instruction(int operation);
void drawing(int n);

#endif